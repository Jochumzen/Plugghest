﻿/*
' Copyright (c) 2014  Plugghest.com
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using System.Collections;
using System.Security.Cryptography.X509Certificates;
using System.Web.UI.WebControls;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Framework;
using DotNetNuke.Security;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.UI.Utilities;
using Plugghest.Helpers;
using Plugghest.Base2;
using System.Collections.Generic;
using Plugghest.DNN;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Text;
using System.Reflection;
using System.Resources;
using System.Globalization;
using System.Threading;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.Script.Services;

namespace Plugghest.Modules.DisplayPlugg
{
    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The View class displays the content
    /// 
    /// Typically your view control would be used to display content or functionality in your module.
    /// 
    /// View may be the only control you have in your project depending on the complexity of your module
    /// 
    /// Because the control inherits from DisplayPluggModuleBase you have access to any custom properties
    /// defined there, as well as properties from DNN such as PortalId, ModuleId, TabId, UserId and many more.
    /// 
    /// </summary>
    /// -----------------------------------------------------------------------------
    public partial class View : DisplayPluggModuleBase, IActionable
    {
        string EditStr = ""; string curlan = ""; int pluggid;
        bool IsAuthorized = false;   
        string AddObj,AddNewcomObj, btnSaveSubjectsObj,YoutubeObj, btnEditObj, btncanceleditObj, btncanceltransObj, btnlocalObj, btntransplugObj, CancelObj, GoogleTransTxtOkObj, ImpgoogleTransObj, ImproveHumTransTxtObj, LabelObj, LatexObj, RemoveObj, RichRichTextObj, RichTextObj, SaveObj, YouTubeObj;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                curlan = (Page as DotNetNuke.Framework.PageBase).PageCulture.Name;
             
                pluggid = Convert.ToInt32(((DotNetNuke.Framework.CDefault)this.Page).Title);
                CallLocalization(curlan,pluggid);
                EditStr = Page.Request.QueryString["edit"];

                if (!IsPostBack)
                {                   
                        PageLoadFun();
                    pnlRRT.Visible = false;
                    pnllabel.Visible = false;
                    pnlletex.Visible = false;
                    richtextbox.Visible = false;
                    pnlLatex.Visible = false;
                    pnlYoutube.Visible = false;
                }
                else
                {
                    if (ViewState["flag"] != null)
                    {                     
                        PageLoadFun();
                    }
                }

            }
            catch (Exception exc) //Module failed to load
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        private void CallLocalization(string curlan, int pluggid)
        {
            PluggContainer p = new PluggContainer(curlan, pluggid);
            btnSaveSubjectsObj = Localization.GetString("btnSaveSubjects", this.LocalResourceFile + ".ascx." + curlan + ".resx");

            btncanceleditObj = Localization.GetString("btncanceledit", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            AddObj = Localization.GetString("Add", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            btncanceltransObj = Localization.GetString("btncanceltrans", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            CancelObj = Localization.GetString("Cancel", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            GoogleTransTxtOkObj = Localization.GetString("GoogleTransTxtOk", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            ImpgoogleTransObj = Localization.GetString("ImpgoogleTrans", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            ImproveHumTransTxtObj = Localization.GetString("ImproveHumTransTxt", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            LabelObj = Localization.GetString("Label", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            LatexObj = Localization.GetString("Latex", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            YoutubeObj = Localization.GetString("YouTube", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            RemoveObj = Localization.GetString("Remove", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            RichRichTextObj = Localization.GetString("RichRichText", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            RichTextObj = Localization.GetString("RichText", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            SaveObj = Localization.GetString("Save", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            YouTubeObj = Localization.GetString("YouTube", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            btnlocalObj = Localization.GetString("btnlocal", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            btnlocalObj = btnlocalObj + "( " + p.ThePlugg.CreatedInCultureCode + " )";
            btntransplugObj = Localization.GetString("btntransplug", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            AddNewcomObj = Localization.GetString("AddNewCom", this.LocalResourceFile + ".ascx." + curlan + ".resx");
            btnEditObj = Localization.GetString("Edit", this.LocalResourceFile + ".ascx." + curlan + ".resx");

            btnlocal.Text = btnlocalObj;
            btnSaveSubjects.Text = btnSaveSubjectsObj;
            btncanceledit.Text = btncanceleditObj;
            btncanceltrans.Text = btncanceltransObj;
            btntransplug.Text = btntransplugObj;
            btncanceledit.Text = btncanceleditObj;
            btnSaveRt.Text = SaveObj;
            btnCanRt.Text = CancelObj;
            btnLabelSave.Text = SaveObj;
            Cancel.Text = CancelObj;
        }

        private void PageLoadFun()
        {
            PluggContainer p = new PluggContainer(curlan, pluggid);
            IsAuthorized = (p.ThePlugg.WhoCanEdit == EWhoCanEdit.Anyone || p.ThePlugg.CreatedByUserId == this.UserId || UserInfo.IsInRole("Administator"));

            if (p.CultureCode == p.ThePlugg.CreatedInCultureCode)
            {
                btnlocal.Visible = false;
                btntransplug.Visible = false;
                btnSaveSubjects.Visible = true;             
            }
            else
            { 
                btnSaveSubjects.Visible = false;
                btncanceledit.Visible = false;
            }
            
                SetPageText(curlan, p);
                ViewState.Add("flag", true);
            //}
            //else
            //   
        }

        private void SetPageText(string curlan, PluggContainer p)
        {

            CheckStr();
            if (p.CultureCode != p.ThePlugg.CreatedInCultureCode)
            {
                if (btncanceledit.Visible == true)
                    Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=" + EditStr, "language=" + p.ThePlugg.CreatedInCultureCode }));
                else
                    DisPlayPluggComp(curlan, p);
            }
            else
            {
                DisPlayPluggComp(curlan, p);
            }
        }

        private void DisPlayPluggComp(string curlan, PluggContainer p)
        {
            List<PluggComponent> comps = p.GetComponentList();
            BaseHandler bh = new BaseHandler();
            string ddl = ""; string str = "</select></div>"; int i = 0;
           

            ddl = CreateDropDown(ddl);

            Label dynamicLabel = new Label();


            var subid = p.ThePlugg.SubjectId;
            CreateSubject(i, subid);

            foreach (PluggComponent comp in comps)
            {
                switch (comp.ComponentType)
                {
                    case EComponentType.Label:

                        PHText lbl = bh.GetCurrentVersionText(curlan, comp.PluggComponentId, ETextItemType.PluggComponentLabel);
                        string divid = "Label" + i;
                        string ddlid = "ddl" + i;
                        int orderid = comp.ComponentOrder;
                        string LabHTMLstring = "";


                        LabHTMLstring = CreateDiv(lbl, divid, LabHTMLstring, LabelObj);
                        //This condition is used for editing plugg
                        if (EditStr == "1" && IsAuthorized == true)
                        {
                            // string lblID = "lbllabel" + i;     

                            CreateBtnDel(i, orderid, "btncsdel", "btnlbDel");

                            CreateBtnEdit(i, comp, lbl, "btncsdel", "btnlbEdit");



                            LabHTMLstring = "</div>"+AddNewcomObj+"<select class='ddlclass' id=" + ddlid + ">";
                            LabHTMLstring = LabHTMLstring + ddl;
                            divTitle.Controls.Add(new LiteralControl(LabHTMLstring));


                            CreateBtnAdd(i, orderid, "btncs", "btnlbAdd");

                            divTitle.Controls.Add(new LiteralControl(str));
                        }
                        //This condition is used for Translation The Plugg Text(same for all cases)
                        else if (EditStr == "2" && IsAuthorized == true)
                        {
                            if (lbl.CultureCodeStatus == ECultureCodeStatus.GoogleTranslated)
                            {

                                CreateImpGoogleTrans(i, comp, lbl, "googletrans", "btnrtIGT");


                                CreateBtnGoogleT(i, lbl, "googleTrasok", "btnGTText");

                            }
                            if (lbl.CultureCodeStatus == ECultureCodeStatus.HumanTranslated)
                            {

                                CreateBtnImproveHumTrans(i, comp, lbl, "btnhumantrans", "btnlbl");

                            }
                            divTitle.Controls.Add(new LiteralControl(str));
                        }
                        break;

                    case EComponentType.RichText:
                        PHText rt = bh.GetCurrentVersionText(curlan, comp.PluggComponentId, ETextItemType.PluggComponentRichText);
                        //Handle rich text
                        string RTdivid = "RichText" + i;
                        string RTddlid = "Rtddl" + i;
                        int RTorderid = comp.ComponentOrder;
                        string RtHTMLstring = "";

                        divTitle.Controls.Add(new LiteralControl(RtHTMLstring));


                        RtHTMLstring = CreateDiv(rt, RTdivid, RtHTMLstring, RichTextObj);

                        if (EditStr == "1" && IsAuthorized == true)
                        {
                            CreateBtnDel(i, RTorderid, "btncsdel", "btnrtDel");

                            CreateBtnEdit(i, comp, rt, "btncsdel", "btnrtEdit");

                            RtHTMLstring = "</div>" + AddNewcomObj + "<select class='ddlclass' id=" + RTddlid + ">";
                            RtHTMLstring = RtHTMLstring + ddl;

                            divTitle.Controls.Add(new LiteralControl(RtHTMLstring));


                            CreateBtnAdd(i, RTorderid, "btncs", "btnrtAdd");

                            divTitle.Controls.Add(new LiteralControl(str));
                        }
                        else if (EditStr == "2" && IsAuthorized == true)
                        {
                            if (rt.CultureCodeStatus == ECultureCodeStatus.GoogleTranslated)
                            {
                                CreateImpGoogleTrans(i, comp, rt, "googletrans", "btnrtIGT");

                                CreateBtnGoogleT(i, rt, "googleTrasok", "btnrtGTText");

                            }
                            if (rt.CultureCodeStatus == ECultureCodeStatus.HumanTranslated)
                            {

                                CreateBtnImproveHumTrans(i, comp, rt, "btnhumantrans", "btnrtIHT");

                            }

                            divTitle.Controls.Add(new LiteralControl(str));
                        }
                        break;

                    case EComponentType.RichRichText:
                        PHText rrt = bh.GetCurrentVersionText(curlan, comp.PluggComponentId, ETextItemType.PluggComponentRichRichText);
                        string RRTdivid = "RichRichText" + i;
                        string RRTddlid = "Rtddl" + i;
                        int RRTorderid = comp.ComponentOrder;
                        string RRTHTMLstring = "";

                        RRTHTMLstring = CreateDiv(rrt, RRTdivid, RRTHTMLstring, RichRichTextObj);

                        if (EditStr == "1" && IsAuthorized == true)
                        {

                            CreateBtnDel(i, RRTorderid, "btncsdel", "btnrrtDel");

                            CreateBtnEdit(i, comp, rrt, "btncsdel", "btnrrtEdit");

                            RRTHTMLstring = "</div>" + AddNewcomObj + "<select class='ddlclass' id=" + RRTddlid + ">";
                            RRTHTMLstring = RRTHTMLstring + ddl;
                            divTitle.Controls.Add(new LiteralControl(RRTHTMLstring));


                            CreateBtnAdd(i, RRTorderid, "btncs", "btnrrtAdd");


                            divTitle.Controls.Add(new LiteralControl(str));
                        }
                        else if (EditStr == "2" && IsAuthorized == true)
                        {

                            if (rrt.CultureCodeStatus == ECultureCodeStatus.GoogleTranslated)
                            {
                                CreateImpGoogleTrans(i, comp, rrt, "googletrans", "btnrrtIGT");
                                CreateBtnGoogleT(i, rrt, "googleTrasok", "btnrrtGTText");
                            }
                            if (rrt.CultureCodeStatus == ECultureCodeStatus.HumanTranslated)
                            {
                                CreateBtnImproveHumTrans(i, comp, rrt, "btnhumantrans", "btnrrtIHT");

                            }

                            divTitle.Controls.Add(new LiteralControl(str));
                        }

                        break;

                    case EComponentType.Latex:
                        PHLatex lat = bh.GetCurrentVersionLatexText(curlan, comp.PluggComponentId, ELatexItemType.PluggComponentLatex);

                        string ltdivid = "Latex" + i;
                        string ltddlid = "ltddl" + i;
                        int ltorderid = comp.ComponentOrder;
                        string LatHTMLstring = "";

                        LatHTMLstring = CreateDivLat(lat, ltdivid, LatHTMLstring);

                        if (EditStr == "1" && IsAuthorized == true)
                        {

                            CreateBtnDel(i, ltorderid, "btncsdel", "btnltDel");

                            Button editbtn = new Button();
                            editbtn.CssClass = "btncsdel";
                            editbtn.ID = "btnltEdit" + i;
                            editbtn.Text = btnEditObj;
                            editbtn.Click += (s, e) => { CallLatFun(ltorderid, comp, lat, "1"); };
                            divTitle.Controls.Add(editbtn);

                            LatHTMLstring = "</div>" + AddNewcomObj + "<select class='ddlclass' id=" + ltddlid + ">";
                            LatHTMLstring = LatHTMLstring + ddl;
                            divTitle.Controls.Add(new LiteralControl(LatHTMLstring));


                            CreateBtnAdd(i, ltorderid, "btncs", "btnlatexAdd");
                            divTitle.Controls.Add(new LiteralControl(str));
                        }

                        break;


                    case EComponentType.YouTube:
                        YouTube yt = bh.GetYouTubeByComponentId(comp.PluggComponentId);
                        string strYoutubeIframe = "";
                        string ytYouTubecode = "";
                        try
                        {
                            strYoutubeIframe = yt.GetIframeString(p.CultureCode);
                        }
                        catch
                        {
                            strYoutubeIframe = "";
                        }
                        if (yt == null)
                        {
                            ytYouTubecode = "(No text)";
                        }
                        else
                        {
                            ytYouTubecode = yt.YouTubeCode;
                        }
                        var ytdivid = "Youtube" + i;
                        var ytddlid = "ytddl" + i;
                        var ytorderid = comp.ComponentOrder;
                        string yourHTMLstring3 = "";
                        if (EditStr == "1" && IsAuthorized == true)
                        {
                            RRTHTMLstring = "<div><div id=" + ytdivid + " class='Main'>" + YoutubeObj + ":" + ytYouTubecode + "";

                            divTitle.Controls.Add(new LiteralControl(RRTHTMLstring));

                            CreateBtnDel(i, ytorderid, "btncsdel", "btnytDel");

                            string IdYt = "btnrrtEdit" + i;

                            CreateBtnYTEdit(i, comp, yt, ytorderid, "btncsdel", IdYt);

                            RRTHTMLstring = "</div>" + strYoutubeIframe + "</br>" + AddNewcomObj + "<select class='ddlclass' id=" + ytddlid + ">";
                            RRTHTMLstring = RRTHTMLstring + ddl;
                            divTitle.Controls.Add(new LiteralControl(RRTHTMLstring));

                            CreateBtnAdd(i, ytorderid, "btncs", "btnytAdd");

                            divTitle.Controls.Add(new LiteralControl(str));
                        }
                        else
                        {
                            yourHTMLstring3 = "<div><div id=" + ytdivid + " class='Main'>  " + YoutubeObj + ":" + ytYouTubecode + "</div>" + strYoutubeIframe + "</div>";
                            divTitle.Controls.Add(new LiteralControl(yourHTMLstring3));
                        }
                        break;
                }
                i++;
            }
        }

        private void CreateBtnImproveHumTrans(int i, PluggComponent comp, PHText lbl, string css, string id)
        {
            Button btn = new Button();
            btn.CssClass = css;
            btn.ID = id + i;
            btn.Text = ImproveHumTransTxtObj;
            btn.Click += (s, e) => { ImpGoogleTrans(comp, lbl); };
            divTitle.Controls.Add(btn);
        }

        private void CreateImpGoogleTrans(int i, PluggComponent comp, PHText lbl, string css, string id)
        {
            Button btn = new Button();
            btn.CssClass = css;
            btn.ID = id + i;
            btn.Text = ImpgoogleTransObj;
            btn.Click += (s, e) => { ImpGoogleTrans(comp, lbl); };
            divTitle.Controls.Add(btn);
        }

     
        private void CreateBtnYTEdit(int i, PluggComponent comp, YouTube yt, int ytorderid, string CssClassD, string IDD)
        {
            Button editbtn = new Button();
            editbtn.CssClass = CssClassD;
            editbtn.ID = IDD + i;
            editbtn.Text = btnEditObj;
            editbtn.Click += (s, e) => { YouTubeEdit(ytorderid, comp, yt); };
            divTitle.Controls.Add(editbtn);
        }

        private string CreateDivLat(PHLatex lat, string ltdivid, string LatHTMLstring)
        {
            if (lat == null)
                LatHTMLstring = "<div><div id=" + ltdivid + " class='Main'>" + LatexObj + ":";
            else
                LatHTMLstring = "<div><div id=" + ltdivid + " class='Main'> " + LatexObj + ":" + lat.Text + "";
            divTitle.Controls.Add(new LiteralControl(LatHTMLstring));
            return LatHTMLstring;
        }

        private void CreateSubject(int i, int? subid)
        {
            if (subid != null)
            {
                string TreeHTMLstring = "";

                int ID = Convert.ToInt32(subid);
                //BindTree(ID);        
                string btnid = "btnTreeEdit" + i;
                string btnclass = "btnTreeEdit";

                if (EditStr == "1" && IsAuthorized == true)
                {
                    TreeHTMLstring = "<input type='button' id=" + btnid + " class=" + btnclass + "  value=" + btnEditObj + " />";
                    divTree.Controls.Add(new LiteralControl(TreeHTMLstring));
                }
            }

        }

        private string CreateDiv(PHText Phtxt, string divid, string HTMLstring,string obj)
        {
            if (Phtxt == null)
                HTMLstring = "<div><div id=" + divid + " class='Main'" + obj + ": ";
            else
                HTMLstring = "<div><div id=" + divid + " class='Main'>" + obj + ":" + Phtxt.Text + "";
            divTitle.Controls.Add(new LiteralControl(HTMLstring));
            return HTMLstring;
        }

        private void CreateBtnAdd(int i, int orderid, string CssClass, string ID)
        {
            Button Addbutton = new Button();
            Addbutton.CssClass = CssClass;
            Addbutton.ID = ID + i;
            Addbutton.Text = AddObj;
            Addbutton.Click += (s, e) => { callingAdd(orderid); };
            divTitle.Controls.Add(Addbutton);
        }

        private void CreateBtnGoogleT(int i, PHText rrt, string CssClassGT, string IDGT)
        {
            Button btnGT = new Button();
            btnGT.CssClass = CssClassGT;
            btnGT.ID = IDGT + i;
            btnGT.Text = GoogleTransTxtOkObj;
            btnGT.Click += (s, e) => { GoogleTranText(rrt); };
            divTitle.Controls.Add(btnGT);
        }

        private void CreateBtnEdit(int i, PluggComponent comp, PHText lbl, string CssClassE, string IDE)
        {
            Button editbtn = new Button();
            editbtn.CssClass = CssClassE;
            editbtn.ID = IDE + i;
            editbtn.Text = btnEditObj;
            editbtn.Click += (s, e) => { ImpGoogleTrans(comp, lbl); };
            divTitle.Controls.Add(editbtn);
        }

        private void CreateBtnDel(int i, int orderid, string CssClass, string ID)
        {
            Button delbtn = new Button();
            delbtn.CssClass = CssClass;
            delbtn.ID = ID + i;
            delbtn.Text = RemoveObj;
            delbtn.Click += (s, e) => { callingDel(orderid); };
            divTitle.Controls.Add(delbtn);
        }

        private void CheckStr()
        {
            if (IsAuthorized == true)
            {
                btncanceledit.Visible = false;
                btncanceltrans.Visible = false;
            }
            else
            {
                btnSaveSubjects.Visible = false;
                btncanceledit.Visible = false;
                btncanceltrans.Visible = false;
            }
            if (EditStr == "1" && IsAuthorized == true)
            {            

                btnSaveSubjects.Visible = false;
                btncanceltrans.Visible = false;
                if (btnSaveSubjects.Visible == true)
                    btncanceledit.Visible = false;
                else
                    btncanceledit.Visible = true;
            }         
            if (EditStr == "2" && IsAuthorized == true)
            {
                btncanceltrans.Visible = true;
                btntransplug.Visible = false;
            }            
        }

        private static string CreateDropDown(string ddl)
        {
            foreach (string name in Enum.GetNames(typeof(EComponentType)))
            {
                if (name != "NotSet")
                {
                    string dl = "<option  value=" + name + " >" + name + "</option>";
                    ddl = ddl + dl;
                }
            }
            return ddl;
        }

      

        private void CallLatFun(int ltorderid, PluggComponent comp, PHLatex lat, string p)
        {

            hdnlabel.Value = Convert.ToString(comp.PluggComponentId);

            switch (comp.ComponentType)
            {
                case EComponentType.Latex:
                    pnlRRT.Visible = true;
                    pnllabel.Visible = false;
                    pnlletex.Visible = false;
                    richtextbox.Visible = false;
                    pnlLatex.Visible = false;
                    pnlYoutube.Visible = false;
                    richrichtext.Text = lat.Text;
                    break;
            }
        }

        private void YouTubeEdit(int ytorderid, PluggComponent comp, YouTube yt)
        {
            string ytcode = "";
            if (yt == null)
                ytcode = "";
            else
                ytcode = yt.YouTubeCode;
            hdnlabel.Value = Convert.ToString(comp.PluggComponentId);

            switch (comp.ComponentType)
            {
                case EComponentType.YouTube:

                    pnlLatex.Visible = false;
                    pnlYoutube.Visible = true;
                    pnlRRT.Visible = false;
                    pnllabel.Visible = false;
                    pnlletex.Visible = false;
                    richtextbox.Visible = false;
                    txtYouTube.Text = ytcode;

                    break;

            }
        }       

        private void GoogleTranText( PHText txt)
        {
            BaseHandler bh = new BaseHandler();
            txt.CultureCodeStatus = ECultureCodeStatus.HumanTranslated;          
            bh.SavePhText(txt);
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=" + EditStr, "language=" + curlan }));
           
        }


        public void BindTree(int subid)
        {
            BaseHandler objBaseHandler = new BaseHandler();       
          
       List<Subject> SubList = (List<Subject>)objBaseHandler.GetSubjectsAsFlatList(curlan);
            string childName = SubList.Find(x => x.SubjectId == subid).label;
            int id = Convert.ToInt32(SubList.Find(x => x.SubjectId == subid).MotherId);
            while (id != 0)
            {
                Subject newSub = SubList.Find(x => x.SubjectId == id);
                childName = newSub.label + ">" + childName;
                id = Convert.ToInt32(newSub.MotherId);
            }

            lbltree.Text = "Subject:" + childName;

            var tree = objBaseHandler.GetSubjectsAsTree(curlan);
            JavaScriptSerializer TheSerializer = new JavaScriptSerializer();
            hdnTreeData.Value = TheSerializer.Serialize(tree);

        }

        private void ImpGoogleTrans(PluggComponent comp, PHText CulTxt)
        {         
            hdnlabel.Value = Convert.ToString(comp.PluggComponentId);

            string text = CulTxt.Text;
            switch (comp.ComponentType)
            {
                case EComponentType.Label:
                    pnlRRT.Visible = false;
                    pnllabel.Visible = true;
                    pnlletex.Visible = false;
                    richtextbox.Visible = false;
                    pnlLatex.Visible = false;
                    pnlYoutube.Visible = false;
                    txtlabel.Text = text;
                    break;

                case EComponentType.RichText:
                    pnlRRT.Visible = false;
                    pnllabel.Visible = false;
                    pnlletex.Visible = false;
                    richtextbox.Visible = true;
                    pnlLatex.Visible = false;
                    pnlYoutube.Visible = false;
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "xx", " $(document).ready(function () {$('#editor').html('" + text.Replace("\r\n", "<br />") + "')});", true);
                    
                    break;
                    
                case EComponentType.RichRichText:

                    pnlRRT.Visible = true;
                    pnllabel.Visible = false;
                    pnlletex.Visible = false;
                    richtextbox.Visible = false;
                    pnlLatex.Visible = false;
                    pnlYoutube.Visible = false;
                    richrichtext.Text = text;
                break;
            }
        }


        private void callingDel(int orderid)
        {
            PluggContainer p = new PluggContainer(curlan, pluggid);
            BaseHandler plugghandler = new BaseHandler();
            plugghandler.DeleteComponent(p, orderid);
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=1" , "language=" + curlan }));

        }

        private void callingAdd(int orderid)
        {
            var id = hdn.Value;          
        
            BaseHandler plugghandler = new BaseHandler();
            PluggContainer p = new PluggContainer(curlan, pluggid);
            PluggComponent pc = new PluggComponent();
            pc.ComponentOrder = orderid + 1;          
            pc.ComponentType = (EComponentType)Enum.Parse(typeof(EComponentType), id);
            plugghandler.AddComponent(p, pc);
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=1", "language=" + curlan }));


        }

        protected void btnEditPlugg_Click(object sender, EventArgs e)
        {
            btncanceledit.Visible = true;
            btnSaveSubjects.Visible = false;

            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=1", "language=" + curlan }));
        }

  

        public ModuleActionCollection ModuleActions 
        {
            get
            {
                var actions = new ModuleActionCollection
                    {
                        {
                            GetNextActionID(), Localization.GetString("EditModule", LocalResourceFile), "", "", "",
                            EditUrl(), false, SecurityAccessLevel.Edit, true, false
                        }
                    };
                return actions;
            }
        }

        protected void btncanceledit_Click(object sender, EventArgs e)
        {
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "test=2", "language=" + curlan }));
        }

        protected void btnLabelSave_Click(object sender, EventArgs e)
        {
            var id = hdnlabel.Value;
            var itemid = Convert.ToInt32(id);
            PluggContainer p = new PluggContainer(curlan, pluggid);
            List<PluggComponent> comps = p.GetComponentList();
            PluggComponent cToAdd = comps.Find(x => x.PluggComponentId == Convert.ToInt32(id));
            BaseHandler bh = new BaseHandler();

            var comtype = cToAdd.ComponentType;

            PHText lbl = bh.GetCurrentVersionText(curlan, itemid, ETextItemType.PluggComponentLabel);

            lbl.Text = txtlabel.Text;

              if (EditStr == "2")          
                lbl.CultureCodeStatus = ECultureCodeStatus.HumanTranslated;
            bh.SavePhText(lbl);
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=" + EditStr, "language=" + curlan }));
           

        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=" + EditStr, "language=" + curlan }));
        }

        protected void btntransplug_Click(object sender, EventArgs e)
        {
            btntransplug.Visible = false;
            btncanceltrans.Visible = true;
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=2" , "language=" + curlan }));
          
        }

        protected void btnSaveRt_Click(object sender, EventArgs e)
        {
            var id = hdnlabel.Value;
            var itemid = Convert.ToInt32(id);         
            PluggContainer p = new PluggContainer(curlan, pluggid);
            List<PluggComponent> comps = p.GetComponentList();
            PluggComponent cToAdd = comps.Find(x => x.PluggComponentId == Convert.ToInt32(id));
            BaseHandler bh = new BaseHandler();

            var comtype = cToAdd.ComponentType;

            PHText RichText = bh.GetCurrentVersionText(curlan, itemid, ETextItemType.PluggComponentRichText);

            RichText.Text = hdnrichtext.Value;
          
            if (EditStr == "2")
                RichText.CultureCodeStatus = ECultureCodeStatus.HumanTranslated;        

            bh.SavePhText(RichText);
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=" + EditStr, "language=" + curlan }));


        }

        protected void btnlocal_Click(object sender, EventArgs e)
        {         
            PluggContainer p = new PluggContainer(curlan, pluggid);

            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "test=2","language=" + p.ThePlugg.CreatedInCultureCode }));

        }

        protected void btncanceltrans_Click(object sender, EventArgs e)
        {
            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "test=2", "language=" + curlan }));
        }

        protected void btnSaveRRt_Click(object sender, EventArgs e)
        {
            var id = hdnlabel.Value;
            var itemid = Convert.ToInt32(id);
         
            PluggContainer p = new PluggContainer(curlan, pluggid);
            List<PluggComponent> comps = p.GetComponentList();
            PluggComponent cToAdd = comps.Find(x => x.PluggComponentId == Convert.ToInt32(id));
            BaseHandler bh = new BaseHandler();

            var comtype = cToAdd.ComponentType;
            PHText RichRichText = null;
            switch (cToAdd.ComponentType)
            {
                case EComponentType.RichRichText:
                    RichRichText = bh.GetCurrentVersionText(curlan, itemid, ETextItemType.PluggComponentRichRichText);
                    RichRichText.Text = richrichtext.Text;
                    if (EditStr == "2")
                        RichRichText.CultureCodeStatus = ECultureCodeStatus.HumanTranslated;                   

                    bh.SavePhText(RichRichText);
                    break;

                case EComponentType.Latex:

                    PHLatex latex = bh.GetCurrentVersionLatexText(curlan, Convert.ToInt32(id), ELatexItemType.PluggComponentLatex);

                    latex.Text = richrichtext.Text;
                    bh.SaveLatexText(latex);
                    break;
            }

            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=" + EditStr, "language=" + curlan }));


        }

        protected void btnYtSave_Click(object sender, EventArgs e)
        {
            var id = hdnlabel.Value;
            var itemid = Convert.ToInt32(id);

           
            PluggContainer p = new PluggContainer(curlan, pluggid);
            List<PluggComponent> comps = p.GetComponentList();

            BaseHandler bh = new BaseHandler();


            List<object> objToadd = new List<object>();

            YouTube yt = bh.GetYouTubeByComponentId(Convert.ToInt32(id));
            if (yt == null)
                yt = new YouTube();
            try
            {
                yt.YouTubeTitle = yttitle.Value;
                yt.YouTubeDuration = Convert.ToInt32(ytduration.Value);
                yt.YouTubeCode = ytYouTubeCode.Value;
                yt.YouTubeAuthor = ytAuthor.Value;
                yt.YouTubeCreatedOn = Convert.ToDateTime(ytYouTubeCreatedOn.Value);
                yt.YouTubeComment = ytYouTubeComment.Value;
                yt.PluggComponentId = itemid;
            }
            catch
            {

            }

            bh.SaveYouTube(yt);

            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=1", "language=" + curlan }));
        }

        protected void btnLatexSave_Click(object sender, EventArgs e)
        {

            var id = hdnlabel.Value;
            var itemid = Convert.ToInt32(id);

         
            PluggContainer p = new PluggContainer(curlan, pluggid);
            List<PluggComponent> comps = p.GetComponentList();

            BaseHandler bh = new BaseHandler();


            List<object> objToadd = new List<object>();

            PHLatex lt = bh.GetCurrentVersionLatexText(curlan, Convert.ToInt32(id), ELatexItemType.PluggComponentLatex);
            lt.HtmlText = richrichtext.Text;
            objToadd.Add(lt);

            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=1" , "language=" + curlan }));

        }

        protected void btnSelSub_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(hdnNodeSubjectId.Value))
            {
                int id = Convert.ToInt32(hdnNodeSubjectId.Value);
             
                BaseHandler plugghandler = new BaseHandler();
                PluggContainer p = new PluggContainer(curlan, pluggid);
                p.ThePlugg.SubjectId = id;
                p.LoadTitle();
                List<object> blankList = new List<object>();             
                BaseHandler bh = new BaseHandler();
                   try
                {
                    bh.SavePlugg(p, blankList);
                }
                catch (Exception)
                {
                }
            }

            Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId, "", new string[] { "edit=" + EditStr, "language=" + curlan }));

        }
    }
}